/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datasewaDAO;
import java.sql.*;
import java.util.*;
import Connector.Connector;
import model.*;
import DAOImplement.*;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Lab Informatika
 */
public class datasewaDAO implements DataSewaImplement {
    Connection connection;
    final String select = "SELECT * FROM sewa_buku";
    final String insert = "INSERT INTO sewa_buku "
            + "(id, nama_penyewa, judul_buku, jenis_buku, nomor_telepon, durasi_sewa, total_biaya) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?)";
    final String update = "UPDATE sewa_buku set nama_penyewa =?, judul_buku=?, "
            + "jenis_buku =?, nomor_telpon =?, durasi_sewa =?, total_biaya =? where id=?";
    final String delete = "DELETE FROM data_sewa where id =?";
    
    public datasewaDAO(){
    connection = Connector.connection();
}
    @Override
    public void insert(datasewa f){
      PreparedStatement statement = null;
      try{
        statement = connection.prepareStatement(insert,Statement.RETURN_GENERATED_KEYS);
        statement.setDouble(1, f.getid());
        statement.setString(2, f.getnama_penyewa());
        statement.setString(3, f.getjudul_buku());
        statement.setString(4, f.getjenis_buku());
        statement.setString(5, f.getnomor_telpon());
        statement.setDouble(6, f.getdurasi_sewa());
        statement.setDouble(7, f.gettotal_biaya());
        statement.executeUpdate();
        ResultSet rs = statement.getGeneratedKeys();
        
        while(rs.next()){
            f.setid(rs.getDouble(0));
        }
        throw new SQLException("data telah ditambahkan");
      }catch(SQLException ex){
          ex.printStackTrace();
      }finally{
          try{
              statement.close();
          }catch(SQLException ex){
              ex.printStackTrace();
          }
      }
    }
    
    
    @Override
    public void update(datasewa f){
         PreparedStatement statement = null;
      try{
        statement = connection.prepareStatement(update,Statement.RETURN_GENERATED_KEYS);
        statement.setDouble(7, f.getid());
        statement.setString(1, f.getnama_penyewa());
        statement.setString(2, f.getjudul_buku());
        statement.setString(3, f.getjenis_buku());
        statement.setString(4, f.getnomor_telpon());
        statement.setDouble(5, f.getdurasi_sewa());
        statement.setDouble(6, f.gettotal_biaya());
        statement.executeUpdate();
        
        
      }catch(SQLException ex){
          ex.printStackTrace();
      }finally{
          try{
              statement.close();
          }catch(SQLException ex){
              ex.printStackTrace();
          }
      }
    }
    @Override
    public void delete(Double id){
         PreparedStatement statement = null;
      try{
        statement = connection.prepareStatement(delete,Statement.RETURN_GENERATED_KEYS);
        statement.setDouble(1, id);
        
        statement.executeUpdate();
        ResultSet rs = statement.getGeneratedKeys();
        
       
        throw new SQLException("data telah ditambahkan");
      }catch(SQLException ex){
          ex.printStackTrace();
      }finally{
          try{
              statement.close();
          }catch(SQLException ex){
              ex.printStackTrace();
          }
      }
    }

    @Override
    public List<datasewa> getAll() {
        List<datasewa> ds = null;
        try{
            ds = new ArrayList<datasewa>();
            Statement st =connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while(rs.next()){
                datasewa sewa = new datasewa();
                sewa.setid(rs.getDouble("id"));
                sewa.setnama_penyewa(rs.getString("nama_penyewa"));
                sewa.setjudul_buku(rs.getString("judul_buku"));
                sewa.setjenis_buku(rs.getString("jenis_buku"));
                sewa.setnomor_telpon(rs.getString("nomor_telepon"));
                sewa.setdurasi_sewa(rs.getDouble("durasi_sewa"));
                sewa.settotal_biaya(rs.getDouble("total_biaya"));
                ds.add(sewa);
            }
            
        }catch(SQLException ex){
            //Logger.getLogger(datasewaDAO.class.getName().log(Level.SEVERE,null,ex));
        }
        return ds;
    }
    
    
    }
    

