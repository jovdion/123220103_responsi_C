/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Connector;
import com.mysql.cj.jdbc.MysqlDataSource;
import java.sql.Connection;
import java.sql.SQLException;
/**
 *
 * @author Lab Informatika
 */
public class Connector {
    static Connection con;

public Connector(){
}
public static Connection connection(){
if (con == null) {
MysqlDataSource data = new MysqlDataSource();
data.setDatabaseName("db_responsi");
data.setUser("root");
data.setPassword("");

try{
con = data.getConnection();
System.out.println("koneksi berhasil");
}catch(SQLException var2){

System.out.println("koneksi gagal");
}
}return con;
}
}