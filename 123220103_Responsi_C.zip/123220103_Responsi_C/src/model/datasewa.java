/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Lab Informatika
 */
public class datasewa {
    private double tambahHari;
    private double id;
    private String nama_penyewa;
    private String judul_buku;
    private String jenis_buku;
    private String nomor_telpon;
    private double durasi_sewa;
    private double total_biaya;
    


public Double getid(){
return id;
}

public void setid(double id){
    this.id = id;
}

public String getnama_penyewa(){
return nama_penyewa;
}
public void setnama_penyewa(String nama_penyewa){
    this.nama_penyewa = nama_penyewa;
}

public String getjudul_buku(){
return judul_buku;
}
public void setjudul_buku(String judul_buku){
    this.judul_buku = judul_buku;
}

public String getjenis_buku(){
return jenis_buku;
}
public void setjenis_buku(String jenis_buku){
    this.jenis_buku = jenis_buku;
}

public String getnomor_telpon(){
return nomor_telpon;
}
public void setnomor_telpon(String nomor_telpon){
    this.nomor_telpon = nomor_telpon;
}

public double getdurasi_sewa(){
return durasi_sewa;
}
public void setdurasi_sewa(double durasi_sewa){
    this.durasi_sewa = durasi_sewa;
}

public double gettotal_biaya(){
if(this.durasi_sewa <=2){
    this.total_biaya = this.durasi_sewa * 10000;
}else {
    this.tambahHari = (this.durasi_sewa - 2) * 10000;
    this.total_biaya = this.durasi_sewa * 5000 + this.tambahHari;
}
return this.total_biaya;
}
public void settotal_biaya(double total_biaya){
    this.total_biaya = total_biaya;
}


}