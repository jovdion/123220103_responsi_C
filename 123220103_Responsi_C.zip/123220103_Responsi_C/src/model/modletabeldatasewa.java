/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.util.List;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author Lab Informatika
 */
public class modletabeldatasewa extends AbstractTableModel{
    List<datasewa> ds;
    public modletabeldatasewa(List <datasewa> ds){
        this.ds = ds;
    }
    
    @Override
    public int getRowCount(){
        return ds.size();
        
    }
    @Override
    public int getColumnCount(){
        return 7;
    }
    
    public String getColumnName(int column){
        switch(column){
            case 0:
                return "id";
            case 1:
                return "Nama_Penyewa";
            case 2:
                return "Judul_buku";
            case 3:
                return "jenis_buku";
            case 4:
                return "Nomor_telepon";
            case 5:
                return "Durasi_Sewa";
            case 6:
                return "Total_Biaya";
            default :
                return null;
            
        }
    }
    

    @Override
    public Object getValueAt(int row, int column) {
        switch(column){
            case 0:
                return ds.get(row).getid();
            case 1:
                return ds.get(row).getnama_penyewa();
            case 2:
                return ds.get(row).getjudul_buku();
            case 3:
                return ds.get(row).getjenis_buku();
            case 4:
                return ds.get(row).getnomor_telpon();
            case 5:
                return ds.get(row).getdurasi_sewa();
            case 6:
                return ds.get(row).gettotal_biaya();
            default:
                return null;
                
        }
    }
    
}
